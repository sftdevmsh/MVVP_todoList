package msh.mvvm.todo.dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

import msh.mvvm.todo.entity.ToDo;

@Dao
public interface DaoToDo {

    @Insert
    void insert(ToDo todo);

    @Update
    void update(ToDo todo);

    @Delete
    void delete(ToDo toDo);

    @Query("select * from t_todo order by level")
    List<ToDo> getAll();

    @Query("select * from t_todo where id=:id")
    ToDo get(int id);

}
