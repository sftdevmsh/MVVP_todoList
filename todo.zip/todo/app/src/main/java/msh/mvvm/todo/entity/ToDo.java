package msh.mvvm.todo.entity;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Index;
import android.arch.persistence.room.PrimaryKey;

import androidx.annotation.Nullable;

import javax.annotation.processing.Generated;

@Entity(tableName = "t_todo")
//        ,indices = {@Index(value = {"order"}, unique = true)})
public class ToDo
{
    @PrimaryKey(autoGenerate = true)
    int id;
    @Nullable
    String title;
    @ColumnInfo(name = "desc")
    String description;
    boolean done;
    int level=id;
}
