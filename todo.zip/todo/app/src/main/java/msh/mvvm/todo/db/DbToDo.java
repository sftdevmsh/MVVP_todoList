package msh.mvvm.todo.db;
import android.arch.persistence.room.RoomDatabase;


public class DbToDo extends RoomDatabase{
}
